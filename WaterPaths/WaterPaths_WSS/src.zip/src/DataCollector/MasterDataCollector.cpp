//;;
// Created by bernardoct on 8/26/17.
//

#include <fstream>
#include <iomanip>
#include <sstream>
#include <sys/stat.h>
#include <numeric>
#include <random>
#include <algorithm>
#include "../DroughtMitigationInstruments/TransfersBilateral.h"

#ifdef NETCDF
#include <netcdf> 
using namespace std;
using namespace netCDF;
using namespace netCDF::exceptions;
// Return this in event of a problem.
#define ERRCODE 2
#define ERR(e) {printf("Error: %s\n", nc_strerror(e)); exit(ERRCODE);}
static const int NC_ERR = 2;
#define DEFLATE_LEVEL_9 9
#endif

#include "MasterDataCollector.h"
#include "../Utils/ObjectivesCalculator.h"
#include "../Utils/Utils.h"
#include "../DroughtMitigationInstruments/Transfers.h"
#include "TransfersDataCollector.h"
#include "../SystemComponents/WaterSources/Quarry.h"
#include "../SystemComponents/WaterSources/WaterReuse.h"
#include "../SystemComponents/WaterSources/AllocatedReservoir.h"
#include "ReservoirDataCollector.h"
#include "IntakeDataCollector.h"
#include "QuaryDataCollector.h"
#include "WaterReuseDataCollector.h"
#include "AllocatedReservoirDataCollector.h"
#include "EmptyDataCollector.h"
#include "TransfersBilateralDataCollector.h"

using namespace Constants;

int MasterDataCollector::seed = NON_INITIALIZED;

MasterDataCollector::MasterDataCollector(vector<unsigned long> &realizations_to_run)
        : n_realizations(*max_element(realizations_to_run.begin(), realizations_to_run.end()) + 1),
        realizations_ran(realizations_to_run) {}

MasterDataCollector::~MasterDataCollector() {
    for (vector<DataCollector *> dcs : water_source_collectors)
        for (DataCollector *dc : dcs)
            delete dc;

    for (vector<DataCollector *> dcs : drought_mitigation_policy_collectors)
        for (DataCollector *dc : dcs)
            delete dc;

    for (vector<UtilitiesDataCollector *> dcs : utility_collectors)
        for (UtilitiesDataCollector *dc : dcs)
            delete dc;
    
    for (vector<WSSDataCollector *> dcs : wss_collectors)
        for (WSSDataCollector *dc : dcs)
            delete dc;
}

/**
* @todo NetCDF file being saved with hardly any compression. Someone who knows more
* about NetCDF may be able to improve compression, which would be great given the 
* amount of output that can be generated in one run.
*/
int MasterDataCollector::printNETCDFUtilities(string base_file_name) {
#ifdef NETCDF
    unsigned long n_weeks = utility_collectors[0][realizations_ran[0]]->getCombined_storage().size();
    unsigned long n_realizations = utility_collectors[0].size();
    unsigned long n_utilities = utility_collectors.size();
    unsigned long n_vars = 6;

    try {
	string file_name = io_directory + base_file_name + ".nc";
	printf("Printing NetCDF output in %s.\n", file_name.c_str());
	int ncid, dimid, csid, strofid, retval;
	vector<int> group_ids(n_realizations);
	vector<int> utilities_group_ids(n_utilities * n_realizations);
	vector<int> vars_ids(n_utilities * n_realizations * n_vars);

        /* Create the file. The NC_NETCDF4 flag tells netCDF to
         * create a netCDF-4/HDF5 file.
	 * */
        if ((retval = nc_create(file_name.c_str(), NC_NETCDF4|NC_CLOBBER, &ncid)))
		               ERR(retval);

        nc_def_dim(ncid, "weeks", n_weeks, &dimid);
        for (int r = 0; r < (int) n_realizations; ++r) {
	    if ((retval = nc_def_grp(ncid, (string("realization_") + to_string(r)).c_str(), &group_ids[r])))
		             ERR (retval);
	    for (int u = 0; u < (int) n_utilities; ++u) {
	        if ((retval = nc_def_grp(group_ids[r], utility_collectors[u][r]->name, &utilities_group_ids[n_utilities * r + u])))
		                 ERR (retval);	    

                if ((retval = nc_def_var(utilities_group_ids[n_utilities * r + u], "storage", 
						NC_FLOAT, 1, &dimid, &vars_ids[n_utilities * r * n_vars + u])))
                    ERR(retval);
                if ((retval = nc_def_var(utilities_group_ids[n_utilities * r + u], "st_rof", 
						NC_FLOAT, 1, &dimid, &vars_ids[n_utilities * r * n_vars + u + 1])))
                    ERR(retval);
                if ((retval = nc_def_var(utilities_group_ids[n_utilities * r + u], "lt_rof", 
						NC_FLOAT, 1, &dimid, &vars_ids[n_utilities * r * n_vars + u + 2])))
                    ERR(retval);
                if ((retval = nc_def_var(utilities_group_ids[n_utilities * r + u], "res_demand", 
						NC_FLOAT, 1, &dimid, &vars_ids[n_utilities * r * n_vars + u + 3])))
                    ERR(retval);
                if ((retval = nc_def_var(utilities_group_ids[n_utilities * r + u], "cf_size", 
						NC_FLOAT, 1, &dimid, &vars_ids[n_utilities * r * n_vars + u+ 4])))
                    ERR(retval);
                if ((retval = nc_def_var(utilities_group_ids[n_utilities * r + u], "infr_pmts", 
						NC_FLOAT, 1, &dimid, &vars_ids[n_utilities * r * n_vars + u + 5])))
                    ERR(retval);

                if ((retval = nc_def_var_deflate(utilities_group_ids[n_utilities * r + u], 
						vars_ids[n_utilities * r * n_vars + u], 1, 1, DEFLATE_LEVEL_9)))
                    ERR(retval);
                if ((retval = nc_def_var_deflate(utilities_group_ids[n_utilities * r + u], 
						vars_ids[n_utilities * r * n_vars + u + 1], 1, 1, DEFLATE_LEVEL_9)))
                    ERR(retval);
                if ((retval = nc_def_var_deflate(utilities_group_ids[n_utilities * r + u], 
						vars_ids[n_utilities * r * n_vars + u + 2], 1, 1, DEFLATE_LEVEL_9)))
                    ERR(retval);
                if ((retval = nc_def_var_deflate(utilities_group_ids[n_utilities * r + u], 
						vars_ids[n_utilities * r * n_vars + u + 3], 1, 1, DEFLATE_LEVEL_9)))
                    ERR(retval);
                if ((retval = nc_def_var_deflate(utilities_group_ids[n_utilities * r + u], 
						vars_ids[n_utilities * r * n_vars + u + 4], 1, 1, DEFLATE_LEVEL_9)))
                    ERR(retval);
                if ((retval = nc_def_var_deflate(utilities_group_ids[n_utilities * r + u], 
						vars_ids[n_utilities * r * n_vars + u + 5], 1, 1, DEFLATE_LEVEL_9)))
                    ERR(retval);

                if ((retval = nc_put_var_double(utilities_group_ids[n_utilities * r + u], vars_ids[n_utilities * r * n_vars + u],
						utility_collectors[u][r]->getCombined_storage().data())))
	            ERR(retval);
                if ((retval = nc_put_var_double(utilities_group_ids[n_utilities * r + u], vars_ids[n_utilities * r * n_vars + u + 1],
						utility_collectors[u][r]->getSt_rof().data())))
	            ERR(retval);
                if ((retval = nc_put_var_double(utilities_group_ids[n_utilities * r + u], vars_ids[n_utilities * r * n_vars + u + 2],
						utility_collectors[u][r]->getLt_rof().data())))
	            ERR(retval);
                if ((retval = nc_put_var_double(utilities_group_ids[n_utilities * r + u], vars_ids[n_utilities * r * n_vars + u + 3],
						utility_collectors[u][r]->getRestricted_demand().data())))
	            ERR(retval);
                if ((retval = nc_put_var_double(utilities_group_ids[n_utilities * r + u], vars_ids[n_utilities * r * n_vars + u + 4],
						utility_collectors[u][r]->getContingency_fund_size().data())))
	            ERR(retval);
                if ((retval = nc_put_var_double(utilities_group_ids[n_utilities * r + u], vars_ids[n_utilities * r * n_vars + u + 5],
						utility_collectors[u][r]->getDebt_service_payments().data())))
	            ERR(retval);
	    }
	}
	return 0;
    } catch(NcException& e){
        e.what();
        return NC_ERR;
    }
#else
    printf("This version of WaterPaths was not compiled with NetCDF. NetCDF result files will not be printed.\n");
    return 1;
#endif
}

void MasterDataCollector::printPoliciesOutputCompact(
        int week_i, int week_f, string file_name) {
    // Print ACTUAL WSS restriction multipliers (what was applied to each WSS)
    // NOT the policy decisions (which are misleading since policies apply to all WSS)
    if (!wss_collectors.empty()) {
#pragma omp parallel for
        for (int rr = 0; rr < (int) realizations_ran.size(); ++rr) {
            auto r = realizations_ran[rr];
            std::ofstream out_stream;
            out_stream.open(output_directory + file_name + "_r"
                            + std::to_string(r) + ".csv");

            // Build header: WSS restriction multipliers + any other policy data (transfers, etc.)
            string line = "";
            // First, add WSS restriction multipliers
            for (const auto& wss_vec : wss_collectors) {
                if (wss_vec[r] != nullptr) {
                    line += std::to_string(wss_vec[r]->id) + "rest_m,";
                }
            }
            // Then add non-restriction policies (transfers, insurance, etc.)
            for (vector<DataCollector *> p : drought_mitigation_policy_collectors) {
                if (p[r]->type != RESTRICTIONS) {
                    line += p[r]->printCompactStringHeader();
                }
            }
            if (!line.empty() && line.back() == ',') line.pop_back();
            out_stream << line << endl;

            // Print data for each week
            for (int w = week_i; w < week_f; ++w) {
                line = "";
                // First, print WSS restriction multipliers (actual applied values)
                for (const auto& wss_vec : wss_collectors) {
                    if (wss_vec[r] != nullptr) {
                        const auto& demand_mults = wss_vec[r]->getDemand_multiplier();
                        if (w < (int)demand_mults.size()) {
                            line += std::to_string(demand_mults[w]) + ",";
                        } else {
                            line += "1.0,";  // Default if data not available
                        }
                    }
                }
                // Then print other policy data (transfers, etc.)
                for (vector<DataCollector *> p : drought_mitigation_policy_collectors) {
                    if (p[r]->type != RESTRICTIONS) {
                        line += p[r]->printCompactString(w);
                    }
                }
                if (!line.empty() && line.back() == ',') line.pop_back();
                out_stream << line << endl;
            }

            out_stream.close();
        }
    } else if (!drought_mitigation_policy_collectors.empty()) {
        // Fallback to old behavior if no WSS collectors (shouldn't happen in WSS model)
#pragma omp parallel for
        for (int rr = 0; rr < (int) realizations_ran.size(); ++rr) {
            auto r = realizations_ran[rr];
            std::ofstream out_stream;
            out_stream.open(output_directory + file_name + "_r"
                            + std::to_string(r) + ".csv");

            string line;
            for (vector<DataCollector *> p : drought_mitigation_policy_collectors)
                line += p[r]->printCompactStringHeader();
            line.pop_back();
            out_stream << line << endl;

            for (int w = week_i; w < week_f; ++w) {
                line = "";
                for (vector<DataCollector *> p : drought_mitigation_policy_collectors)
                    line += p[r]->printCompactString(w);
                line.pop_back();
                out_stream << line << endl;
            }

            out_stream.close();
        }
    }
}


void MasterDataCollector::printPoliciesOutputTabular(
        int week_i, int week_f, string file_name) {
    if (!drought_mitigation_policy_collectors.empty()) {
#pragma omp parallel for
        for (int rr = 0; rr < (int) realizations_ran.size(); ++rr) {
            auto r = realizations_ran[rr];
            std::ofstream out_stream;
            out_stream.open(output_directory + file_name + "_r"
                            + std::to_string(r) + ".tab");

            out_stream << "    ";
            for (vector<DataCollector *> p : drought_mitigation_policy_collectors)
                out_stream << p[r]->printTabularStringHeaderLine1();
            out_stream << endl;

            out_stream << "Week";
            for (vector<DataCollector *> p : drought_mitigation_policy_collectors)
                out_stream << p[r]->printTabularStringHeaderLine2();
            out_stream << endl;

            for (int w = week_i; w < week_f; ++w) {
                out_stream << setw(4) << w;
                for (vector<DataCollector *> p : drought_mitigation_policy_collectors)
                    out_stream << p[r]->printTabularString(w);
                out_stream << endl;
            }

            out_stream.close();
        }
    }
}

void MasterDataCollector::printUtilitiesOutputCompact(
        int week_i, int week_f, string file_name) {
#pragma omp parallel for
    for (int rr = 0; rr < (int) realizations_ran.size(); ++rr) {
        auto r = realizations_ran[rr];
        std::ofstream out_stream;
        out_stream.open(output_directory + file_name + "_r"
                        + std::to_string(r) + ".csv");

        string line;
        for (vector<UtilitiesDataCollector *> &p : utility_collectors)
            line += p[r]->printCompactStringHeader();
        line.pop_back();
        out_stream << line << endl;

        for (int w = week_i; w < week_f; ++w) {
            line = "";
            for (vector<UtilitiesDataCollector *> &p : utility_collectors)
                line += p[r]->printCompactString(w);
            line.pop_back();
            out_stream << line << endl;
        }

        out_stream.close();
    }
}


void MasterDataCollector::printUtilitesOutputTabular(
        int week_i, int week_f, string file_name) {
#pragma omp parallel for
    for (int rr = 0; rr < (int) realizations_ran.size(); ++rr) {
        auto r = realizations_ran[rr];
        std::ofstream out_stream;
        out_stream.open(output_directory + file_name + "_r"
                        + std::to_string(r) + ".tab");

        stringstream names;
        names << "    ";
        for (vector<UtilitiesDataCollector *> &p : utility_collectors)
            names << setw(p[realizations_ran[0]]->table_width) << p[r]->name;

        out_stream << names.str();
        out_stream << endl;

        out_stream << "    ";
        for (vector<UtilitiesDataCollector *> &p : utility_collectors)
            out_stream << p[r]->printTabularStringHeaderLine1();
        out_stream << endl;

        out_stream << "Week";
        for (vector<UtilitiesDataCollector *> &p : utility_collectors)
            out_stream << p[r]->printTabularStringHeaderLine2();
        out_stream << endl;

        for (int w = week_i; w < week_f; ++w) {
            out_stream << setw(4) << w;
            for (vector<UtilitiesDataCollector *> &p : utility_collectors)
                out_stream << p[r]->printTabularString(w);
            out_stream << endl;
        }

        out_stream.close();
    }
}

void MasterDataCollector::printWaterSourcesOutputCompact(
        int week_i, int week_f, string file_name) {
#pragma omp parallel for
    for (int rr = 0; rr < (int) realizations_ran.size(); ++rr) {
        auto r = realizations_ran[rr];
        try {
            std::ofstream out_stream;
            out_stream.open(output_directory + file_name + "_r"
                            + std::to_string(r) + ".csv");

            string line;
            for (vector<DataCollector *> p : water_source_collectors)
                line += p[r]->printCompactStringHeader();
            line.pop_back();
            out_stream << line << endl;

            for (int w = week_i; w < week_f; ++w) {
                line = "";
                for (vector<DataCollector *> p : water_source_collectors)
                    line += p[r]->printCompactString(w);
                line.pop_back();
                out_stream << line << endl;
            }

            out_stream.close();
        } catch (...) {
            printf("Warning: water sources data for realization %lu not saved due to error.\n", r);
        }
    }
}

void MasterDataCollector::printWaterSourcesOutputTabular(
        int week_i, int week_f, string file_name) {
#pragma omp parallel for
    for (int rr = 0; rr < (int) realizations_ran.size(); ++rr) {
        auto r = realizations_ran[rr];
        std::ofstream out_stream;
        out_stream.open(output_directory + file_name + "_r"
                        + std::to_string(r) + ".tab");

        stringstream names;
        names << "    ";
        for (vector<DataCollector *> p : water_source_collectors)
            names << setw(p[realizations_ran[0]]->table_width) << p[r]->name;

        out_stream << names.str();
        out_stream << endl;

        out_stream << "    ";
        for (vector<DataCollector *> p : water_source_collectors)
            out_stream << p[r]->printTabularStringHeaderLine1();
        out_stream << endl;

        out_stream << "Week";
        for (vector<DataCollector *> p : water_source_collectors)
            out_stream << p[r]->printTabularStringHeaderLine2();
        out_stream << endl;

        for (int w = week_i; w < week_f; ++w) {
            out_stream << setw(4) << w;
            for (vector<DataCollector *> p : water_source_collectors)
                out_stream << p[r]->printTabularString(w);
            out_stream << endl;
        }

        out_stream.close();
    }
}

void MasterDataCollector::printWSSOutputCompact(
        int week_i, int week_f, string file_name) {
    // Only print if WSS collectors exist
    if (wss_collectors.empty()) {
        printf("No WSS collectors available - skipping WSS output files.\\n");
        return;
    }

#pragma omp parallel for
    for (int rr = 0; rr < (int) realizations_ran.size(); ++rr) {
        auto r = realizations_ran[rr];
        try {
            std::ofstream out_stream;
            out_stream.open(output_directory + file_name + "_r"
                            + std::to_string(r) + ".csv");

            // Print header
            string line;
            for (vector<WSSDataCollector *> &wss_vec : wss_collectors)
                line += wss_vec[r]->printCompactStringHeader();
            line.pop_back();  // Remove trailing comma
            out_stream << line << endl;

            // Print data for each week
            for (int w = week_i; w < week_f; ++w) {
                line = "";
                for (vector<WSSDataCollector *> &wss_vec : wss_collectors)
                    line += wss_vec[r]->printCompactString(w);
                line.pop_back();  // Remove trailing comma
                out_stream << line << endl;
            }

            out_stream.close();
        } catch (...) {
            char error_msg[256];
            sprintf(error_msg,
                    "Error printing WSS output for realization %lu\\n", r);
            throw runtime_error(error_msg);
        }
    }
}

void MasterDataCollector::printUtilityObjectivesToRowOutStream(vector<UtilitiesDataCollector *> &u,
        std::ofstream &outStream, vector<double> &objectives) {
    try {
    // Create vector with restriction policies pertaining only to the
    // utility whose objectives are being calculated.
    vector<RestrictionsDataCollector *> utility_restrictions(
            *max_element(realizations_ran.begin(), realizations_ran.end()) + 1,
            nullptr
    );
    isolateRestrictionDataCollectors(u, utility_restrictions);

    // Reliability - Use WSS-level calculation (utility = minimum reliability of its WSS)
    double reliability = 1.0;
    if (!wss_collectors.empty()) {
        // CRITICAL: Filter WSS collectors to only include those belonging to this utility
        vector<vector<WSSDataCollector *>> utility_wss_collectors;
        isolateWSSDataCollectors(u, utility_wss_collectors);
        
        if (!utility_wss_collectors.empty()) {
            reliability = ObjectivesCalculator::calculateReliabilityObjective_WSS(utility_wss_collectors, realizations_ran);
        } else {
            // No WSS found for this utility, fallback to utility-level calculation
            reliability = ObjectivesCalculator::calculateReliabilityObjective(u, realizations_ran);
        }
    } else {
        // Fallback to utility-level if WSS collectors not available
        reliability = ObjectivesCalculator::calculateReliabilityObjective(u, realizations_ran);
    }
    
    /// Restriction Frequency
    double restriction_freq = ObjectivesCalculator::
    calculateRestrictionFrequencyObjective(utility_restrictions, realizations_ran);
    
    /// Infrastructure NPC and Worse Case Costs - Use WSS-level calculations
    double inf_npc = 0.0;
    double worse_cost = 0.0;
    if (!wss_collectors.empty()) {
        // Use WSS-level calculations (pass utility data for safe discount rate access)
        inf_npc = ObjectivesCalculator::
        calculateNetPresentCostInfrastructureObjective_WSS(wss_collectors, u, realizations_ran);
        worse_cost = ObjectivesCalculator::
        calculateWorseCaseCostsObjective(u, realizations_ran);
    } else {
        // Fallback to utility-level if WSS collectors not available
        inf_npc = ObjectivesCalculator::
        calculateNetPresentCostInfrastructureObjective(u, realizations_ran);
        worse_cost = ObjectivesCalculator::
        calculateWorseCaseCostsObjective(u, realizations_ran);
    }
    
    /// Peak Financial Cost
    double financial_cost = ObjectivesCalculator::
    calculatePeakFinancialCostsObjective(u, realizations_ran);

    outStream << setw(COLUMN_WIDTH) << u[realizations_ran[0]]->name
              /// Reliability
              << setw(COLUMN_WIDTH * 2)
              << setprecision(COLUMN_PRECISION)
              << reliability
              /// Restriction Frequency
              << setw(COLUMN_WIDTH * 2)
              << setprecision(COLUMN_PRECISION)
              << restriction_freq
              /// Infrastructure NPC
              << setw(COLUMN_WIDTH * 2)
              << setprecision(COLUMN_PRECISION)
              << inf_npc
              /// Peak Financial Cost
              << setw(COLUMN_WIDTH * 2)
              << setprecision(COLUMN_PRECISION)
              << financial_cost
              /// Worse Case Costs
              << setw(COLUMN_WIDTH * 2)
              << setprecision(COLUMN_PRECISION)
              << worse_cost
              << endl;

    objectives.push_back(reliability);
    objectives.push_back(restriction_freq);
    objectives.push_back(inf_npc);
    objectives.push_back(financial_cost);
    objectives.push_back(worse_cost);
    } catch (const std::exception& e) {
        printf("ERROR in printUtilityObjectivesToRowOutStream: %s\n", e.what());
        throw;
    }
}

vector<double> MasterDataCollector::calculatePrintObjectives(string file_name, bool print) {
    vector<double> objectives = vector<double>();

    if (print) {
        printf("Calculating and printing Objectives\n");
        string obj_file_path = output_directory + file_name + ".out";
//        cout << obj_file_path << endl;

        std::ofstream outStream;
        outStream.open(obj_file_path);

        outStream << setw(COLUMN_WIDTH) << "      " << setw((COLUMN_WIDTH * 2))
                  << "Reliability"
                  << setw(COLUMN_WIDTH * 2) << "Restriction Freq."
                  //              << setw(COLUMN_WIDTH * 2) << "Jordan Lake Alloc."
                  << setw(COLUMN_WIDTH * 2) << "Infrastructure NPC"
                  << setw(COLUMN_WIDTH * 2) << "Peak Financial Cost"
                  << setw(COLUMN_WIDTH * 2) << "Worse Case Costs" << endl;

        for (auto &u : utility_collectors) {
            printUtilityObjectivesToRowOutStream(u, outStream, objectives);
        }

        outStream.close();

//        for (int i = 0; i < (int) objectives.size(); ++i) {
//            double o = objectives.at(i);
//            if (o > 10e10 || o < -0.1) {
//                char error[512];
//                sprintf(error, "Objective %d has absurd value of %f. Aborting.\n", i, o);
//                throw_with_nested(runtime_error(error));
//            }
//        }
    } else {
//        cout << "Calculating Objectives" << endl;
        for (auto &u : utility_collectors) {
            // Create vector with restriction policies pertaining only to the
            // utility whose objectives are being calculated.
            vector<RestrictionsDataCollector *> utility_restrictions(
                    *max_element(realizations_ran.begin(), realizations_ran.end()) + 1,
                    nullptr
                    );
            isolateRestrictionDataCollectors(u, utility_restrictions);

            // Reliability - Use WSS-level calculation (utility = minimum reliability of its WSS)
            if (!wss_collectors.empty()) {
                // Filter WSS collectors to only include those belonging to this utility
                vector<vector<WSSDataCollector *>> utility_wss_collectors;
                isolateWSSDataCollectors(u, utility_wss_collectors);
                
                if (!utility_wss_collectors.empty()) {
                    double reliability = ObjectivesCalculator::calculateReliabilityObjective_WSS(utility_wss_collectors, realizations_ran);
                    objectives.push_back(reliability);
                } else {
                    // No WSS found for this utility, fallback to utility-level calculation
                    double reliability = ObjectivesCalculator::calculateReliabilityObjective(u, realizations_ran);
                    objectives.push_back(reliability);
                }
            } else {
                double reliability = ObjectivesCalculator::calculateReliabilityObjective(u, realizations_ran);
                objectives.push_back(reliability);
            }
            
            objectives.push_back
                    (ObjectivesCalculator::calculateRestrictionFrequencyObjective(utility_restrictions, realizations_ran));
            
            // Use WSS-level calculations for infrastructure NPC and worse case costs
            if (!wss_collectors.empty()) {
                // Filter WSS collectors to only include those belonging to this utility
                vector<vector<WSSDataCollector *>> utility_wss_collectors_npc;
                isolateWSSDataCollectors(u, utility_wss_collectors_npc);
                
                objectives.push_back
                        (ObjectivesCalculator::calculateNetPresentCostInfrastructureObjective_WSS(utility_wss_collectors_npc, u, realizations_ran));
            } else {
                objectives.push_back
                        (ObjectivesCalculator::calculateNetPresentCostInfrastructureObjective(u, realizations_ran));
            }
            
            objectives.push_back
                    (ObjectivesCalculator::calculatePeakFinancialCostsObjective(u, realizations_ran));
            
            objectives.push_back
                    (ObjectivesCalculator::calculateWorseCaseCostsObjective(u, realizations_ran));
        }
    }
    return objectives;
}

void MasterDataCollector::isolateRestrictionDataCollectors(vector<UtilitiesDataCollector *> &u,
                                                           vector<RestrictionsDataCollector *> &utility_restrictions) const {
    for (auto &p : drought_mitigation_policy_collectors)
        if (p.at(realizations_ran.at(0))->type == RESTRICTIONS && p[realizations_ran[0]]->id == u.at(realizations_ran[0])->id)
            for (auto i : realizations_ran) {
                utility_restrictions.at(i) =
                        dynamic_cast<RestrictionsDataCollector *>(p.at(i));
            }
}

void MasterDataCollector::isolateWSSDataCollectors(vector<UtilitiesDataCollector *> &u,
                                                   vector<vector<WSSDataCollector *>> &utility_wss_collectors) const {
    // Filter WSS collectors to include only those belonging to the specified utility
    utility_wss_collectors.clear();
    int utility_id = 0;
    if (!u.empty() && !realizations_ran.empty() && u.at(realizations_ran.at(0)) != nullptr) {
        utility_id = u.at(realizations_ran.at(0))->id;
    }
    
    for (const auto &wss_realization_data : wss_collectors) {
        if (!wss_realization_data.empty() && 
            wss_realization_data[realizations_ran[0]] != nullptr) {
            
            // Get owner from data collector (cached during construction, safe even after WSS is deleted)
            const Utility* owner = wss_realization_data[realizations_ran[0]]->getOwner();
            
            // Check owner is not null before accessing id
            if (owner != nullptr && owner->id == utility_id) {
                utility_wss_collectors.push_back(wss_realization_data);
            }
        }
    }
}

unsigned long MasterDataCollector::getActualWeeksCollected() const {
    if (!utility_collectors.empty() && !utility_collectors[0].empty() && 
        !realizations_ran.empty()) {
        return utility_collectors[0][realizations_ran[0]]->getCombined_storage().size();
    }
    return 0;
}

void MasterDataCollector::performBootstrapAnalysis(
		int sol_id, int n_sets, int n_samples, int n_threads, vector<vector<int>> bootstrap_samples) {
    printf("Running bootstrap samples.\n");
    vector<vector<int>> bootstrap_sample_sets((unsigned long) n_sets, vector<int>((unsigned long) n_samples));

    // Create or use specified bootstrap samples
    readOrCreateBSSamples(sol_id, n_sets, n_samples, bootstrap_samples, bootstrap_sample_sets);

    vector<vector<double>> objectives((unsigned long) n_sets);
    for (unsigned long &r : crashed_realizations) {
        for (vector<int> &bs : bootstrap_sample_sets) {
            bs.erase(remove(bs.begin(), bs.end(), r), bs.end());
        }
    }

//#pragma omp parallel for num_threads(n_threads) shared(objectives)
    for (int set = 0; set < n_sets; ++set) {
        // Calculate objectives for the set of bootstrapped realizations.
        vector<unsigned long> bootstrap_sample_set = vector<unsigned long>(
                bootstrap_sample_sets[set].begin(),
                bootstrap_sample_sets[set].end());

        for (unsigned long &r : crashed_realizations) {
            for (unsigned long &bs : bootstrap_sample_set) {
                if (bs >= r) {
                    --bs;
                }
            }
        }

        for (auto &u : utility_collectors) {
            // Create vector with restriction policies pertaining only to the
            // utility whose objectives are being calculated.
            vector<RestrictionsDataCollector *> utility_restrictions(
                    *max_element(realizations_ran.begin(), realizations_ran.end()) + 1
            );
            isolateRestrictionDataCollectors(u, utility_restrictions);

            // Populate vector of objectives for each corresponding set of bootstrap samples.
            objectives[set].push_back
                    (ObjectivesCalculator::calculateReliabilityObjective(u, bootstrap_sample_set));
            objectives[set].push_back
                    (ObjectivesCalculator::calculateRestrictionFrequencyObjective(utility_restrictions, bootstrap_sample_set));
            objectives[set].push_back
                    (ObjectivesCalculator::calculateNetPresentCostInfrastructureObjective(u, bootstrap_sample_set));
            objectives[set].push_back
                    (ObjectivesCalculator::calculatePeakFinancialCostsObjective(u, bootstrap_sample_set));
            objectives[set].push_back
                    (ObjectivesCalculator::calculateWorseCaseCostsObjective(u, bootstrap_sample_set));
        }
    }

    // Print objectives of bootstrap samples
    printObjsBSSamples(sol_id, n_sets, n_samples, objectives);

    // Print objectives of all realizations
    printObjectivesOfAllRealizationsForBSAnalysis(sol_id, n_sets, n_samples);

    // Print bootstrap samples file.
    printBSSamples(sol_id, n_sets, n_samples, bootstrap_sample_sets);

}

void MasterDataCollector::printBSSamples(int sol_id, int n_sets, int n_samples,
                                         const vector<vector<int>> &bootstrap_sample_sets) const {
    ofstream outStream_realizations; // Either read samples from file or create new ones.
    outStream_realizations.open(output_directory + "bootstrap_realizations_" +
                                to_string(n_sets) + "_" + to_string(n_samples) + "_S" +
                                to_string(sol_id) + ".csv");

    string line;
    for (int set = 0; set < n_sets; ++set) {
        // Generate one set of bootstrapped realizations, if none was specified.
        line = "";
        for (int s : bootstrap_sample_sets[set]) {
            line += to_string(s) + ",";
        }
        line.pop_back();
        outStream_realizations << line << endl;
    }

    outStream_realizations.close();
}

void MasterDataCollector::printObjectivesOfAllRealizationsForBSAnalysis(int sol_id, int n_sets, int n_samples) {
    string file_name = output_directory + "objectives_all_reals_" + to_string(n_sets) +
                       "_" + to_string(n_samples) + "_S" + to_string(sol_id) + ".csv";
    vector<double> objectives_all_reals = calculatePrintObjectives("", false);

    string line;
    line = "";
    for (double &o : objectives_all_reals) {
	    line += to_string(o) + ",";
    }
    line.pop_back();

    ofstream outStream_objs_all_reals;
    outStream_objs_all_reals.open(file_name);
    outStream_objs_all_reals << line << endl;

    outStream_objs_all_reals.close();
}

void MasterDataCollector::printObjsBSSamples(int sol_id, int n_sets, int n_samples,
                                              vector<vector<double>> &objectives) {// Print objectives.
    ofstream outStream_objs;
    string objectives_file_name = output_directory + "bootstrap_objs_" + to_string(n_sets) + "_" +
                        to_string(n_samples) + "_S" + to_string(sol_id) + ".csv";
    outStream_objs.open(objectives_file_name);
    printf("Bootstrap objectives files will be printed at %s\n", objectives_file_name.c_str());

    string line;
    for (int set = 0; set < n_sets; ++set) {
        line = "";
        for (double &o : objectives[set]) {
            line += to_string(o) + ",";
        }
        line.pop_back();
        outStream_objs << line << endl;
    }
    outStream_objs.close();
}

void MasterDataCollector::readOrCreateBSSamples(int sol_id, int n_sets, int n_samples,
                                                const vector<vector<int>> &bootstrap_samples,
                                                vector<vector<int>> &bootstrap_sample_sets) const {
    random_device rd;     // only used once to initialise (seed) engine
    mt19937 rng((seed == NON_INITIALIZED ? rd() : seed));    // random-number engine used (Mersenne-Twister in this case)

    int min = 0;
    int max = (int) n_realizations - 1;
    uniform_int_distribution<int> uni(min, max); // guaranteed unbiased
    string line;
    if (!bootstrap_samples.empty()) {
	    bootstrap_sample_sets = bootstrap_samples;
    } else {
        for (int set = 0; set < n_sets; ++set) {
            // Generate one set of bootstrapped realizations, if none was specified.
            for (int &s : bootstrap_sample_sets[set]) {
                s = uni(rng);
            }
        }
    }
}

void MasterDataCollector::printPathways(string file_name) {
    std::ofstream outStream;
    outStream.open(output_directory + file_name + ".out");

    outStream << "Realization\tutility\tWSS\tweek\tinfra." << endl;

    int total_pathways = 0;
    // Collect pathways from WSS collectors (which point to realization WSS where infrastructure is actually built)
    for (auto &wss_collector_vec : wss_collectors)
        for (int rr = 0; rr < (int) realizations_ran.size(); ++rr) {
            auto r = realizations_ran[rr];
            if (wss_collector_vec[r]) {
                vector<vector<int>> pathways = wss_collector_vec[r]->getPathways();
                total_pathways += pathways.size();
                for (const vector<int>& infra : pathways) {
                    // Format: realization, utility_id, wss_id, week, water_source_id
                    outStream << r << "\t" << infra[0] << "\t" << infra[1] << "\t"
                              << infra[2] << "\t" << infra[3] << endl;
                }
            }
        }
    outStream.close();
}

void MasterDataCollector::setOutputDirectory(string io_directory) {
    // Check if io_directory is not being set for the same io_directory it is already set. Avoids unnecessary verbose.
    if (io_directory != output_directory) {
        output_directory = io_directory + DEFAULT_OUTPUT_DIR;
        Utils::createDir(output_directory);
        printf("Output will be printed to folder %s\n", output_directory.c_str());
    }
}

DataCollector* MasterDataCollector::createPolicyDataCollector(DroughtMitigationPolicy* dmp, unsigned long r) {
    if (dmp->type == RESTRICTIONS)
        return new RestrictionsDataCollector(dynamic_cast<Restrictions *> (dmp), r);
    else if (dmp->type == TRANSFERS)
        return new TransfersDataCollector(dynamic_cast<Transfers *> (dmp), r);
    else if (dmp->type == TRANSFERS_CAESB)
        return new TransfersBilateralDataCollector(dynamic_cast<TransfersBilateral *> (dmp), r);
    else if (dmp->type == INSURANCE_STORAGE_ROF)
        return new EmptyDataCollector();
    else
        throw invalid_argument("Drought mitigation policy not recognized. "
                                 "Did you forget to add it to the "
                                 "MasterDataCollector::addRealization"
                                 " function or to create its data collector??");
}

DataCollector* MasterDataCollector::createWaterSourceDataCollector(WaterSource* ws, unsigned long r) {
    if (ws->source_type == RESERVOIR)
        return new ReservoirDataCollector(dynamic_cast<Reservoir *> (ws), r);
    else if (ws->source_type == INTAKE)
        return new IntakeDataCollector(dynamic_cast<Intake *> (ws), r);
    else if (ws->source_type == QUARRY)
        return new QuaryDataCollector(dynamic_cast<Quarry *> (ws), r);
    else if (ws->source_type == WATER_REUSE)
        return new WaterReuseDataCollector(dynamic_cast<WaterReuse *> (ws), r);
    else if (ws->source_type == ALLOCATED_RESERVOIR)
        return new AllocatedReservoirDataCollector(dynamic_cast<AllocatedReservoir *> (ws), r);
    else if (ws->source_type ==
             RESERVOIR_EXPANSION ||
             ws->source_type ==
             NEW_WATER_TREATMENT_PLANT ||
             ws->source_type ==
             SOURCE_RELOCATION)
        return new EmptyDataCollector();
    else
        throw invalid_argument("Water source not recognized. "
                                 "Did you forget to add it to the "
                                 "MasterDataCollector::addRealization"
                                 " function?");
}

void MasterDataCollector::addRealization(
        vector<WaterSource *> water_sources_realization,
        vector<DroughtMitigationPolicy *> drought_mitigation_policies_realization,
        vector<Utility *> utilities_realization,
        const vector<std::unique_ptr<WaterSupplySystems>> &wss_realization,
        unsigned long r) {
    // If collectors vectors have not yet been initialized, initialize them.
#pragma omp critical
    {
        if (water_source_collectors.empty()) {
            water_source_collectors = vector<vector<DataCollector *>>
                    (water_sources_realization.size(), vector<DataCollector *>(n_realizations));
            drought_mitigation_policy_collectors = vector<vector<DataCollector *>>
                    (drought_mitigation_policies_realization.size(), vector<DataCollector *>(n_realizations));
            utility_collectors = vector<vector<UtilitiesDataCollector *>>
                    (utilities_realization.size(), vector<UtilitiesDataCollector *>(n_realizations));
            
            // Count total number of WSS from the realization model
            // These are the WSS where bonds are actually issued during simulation
            wss_collectors = vector<vector<WSSDataCollector *>>
                    (wss_realization.size(), vector<WSSDataCollector *>(n_realizations));
        }
        realizations_created++;
    };

    // Create utilities data collectors
    for (int u = 0; u < (int) utilities_realization.size(); ++u) {
        utility_collectors[u][r] = new UtilitiesDataCollector(utilities_realization[u], r);
    }

    // Create WSS data collectors pointing to realization WSS (where bonds are actually issued)
    // This ensures we collect the correct infrastructure NPC values
    for (size_t wss_index = 0; wss_index < wss_realization.size(); ++wss_index) {
        if (wss_index >= wss_collectors.size()) {
            char error[256];
            sprintf(error, "WSS collector index %zu out of bounds (size=%zu) for realization %lu",
                    wss_index, wss_collectors.size(), r);
            throw std::out_of_range(error);
        }
        if (wss_realization[wss_index] == nullptr || wss_realization[wss_index].get() == nullptr) {
            char error[256];
            sprintf(error, "Realization WSS at index %zu is null for realization %lu", wss_index, r);
            throw std::runtime_error(error);
        }
        wss_collectors[wss_index][r] = new WSSDataCollector(wss_realization[wss_index].get(), r);
    }

    // Create drought mitigation policies data collector
    for (int dmp = 0; dmp < (int) drought_mitigation_policies_realization.size(); ++dmp)
        drought_mitigation_policy_collectors[dmp][r] =
                createPolicyDataCollector(drought_mitigation_policies_realization[dmp], r);

    // Create water sources data collectors
    for (int ws = 0; ws < (int) water_sources_realization.size(); ++ws) {
        water_source_collectors[ws][r] = createWaterSourceDataCollector(water_sources_realization[ws], r);
    }
} 

void MasterDataCollector::removeRealization(unsigned long r) {
    for (int u = 0; u < (int) utility_collectors.size(); ++u) {
        delete utility_collectors[u][r];
        utility_collectors[u][r] = nullptr;
    }
    for (int wss = 0; wss < (int) wss_collectors.size(); ++wss) {
        delete wss_collectors[wss][r];
        wss_collectors[wss][r] = nullptr;
    }
    for (int dmp = 0; dmp < (int) drought_mitigation_policy_collectors.size(); ++dmp) {
	    delete drought_mitigation_policy_collectors[dmp][r];
        drought_mitigation_policy_collectors[dmp][r] = nullptr;
    }
    for (int ws = 0; ws < (int) water_source_collectors.size(); ++ws) {
	    delete water_source_collectors[ws][r];
        water_source_collectors[ws][r] = nullptr;
    }

    realizations_ran.erase(std::remove(realizations_ran.begin(), realizations_ran.end(), r), realizations_ran.end());
    crashed_realizations.push_back(r);
}


void MasterDataCollector::cleanCollectorsOfDeletedRealizations() {

    for (auto &v : utility_collectors) {
        v.erase(remove_if(v.begin(), v.end(), [](const void *x) { return x == nullptr; }), v.end());
    }
    for (auto &v : wss_collectors) {
        v.erase(remove_if(v.begin(), v.end(), [](const void *x) { return x == nullptr; }), v.end());
    }
    for (auto &v : drought_mitigation_policy_collectors) {
        v.erase(remove_if(v.begin(), v.end(), [](const void *x) { return x == nullptr; }), v.end());
    }
    for (auto &v : water_source_collectors) {
        v.erase(remove_if(v.begin(), v.end(), [](const void *x) { return x == nullptr; }), v.end());
    }
}


void MasterDataCollector::collectData(unsigned long r) {
    for (vector<UtilitiesDataCollector *> &uc : utility_collectors)
        uc[r]->collect_data();
    for (vector<WSSDataCollector *> &wss : wss_collectors)
        wss[r]->collect_data();
    for (vector<DataCollector *> dmp : drought_mitigation_policy_collectors)
        dmp[r]->collect_data();
    for (vector<DataCollector *> ws : water_source_collectors)
        ws[r]->collect_data();
}

void MasterDataCollector::setSeed(int seed) {
    MasterDataCollector::seed = seed;
}

void MasterDataCollector::unsetSeed() {
    MasterDataCollector::seed = NON_INITIALIZED;
}

int MasterDataCollector::getRealizations_created() const {
    return realizations_created;
}
