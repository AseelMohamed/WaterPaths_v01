//
// Created by bernardoct on 7/9/17.
//

#include <algorithm>
#include <iostream>
#include <numeric>
#include "AllocatedReservoir.h"


AllocatedReservoir::AllocatedReservoir(
        const char *name, const int id, const vector<Catchment *> &catchments,
        const double capacity, const double max_treatment_capacity,
        EvaporationSeries &evaporation_series, DataSeries *storage_area_curve,
        vector<int> *wss_with_allocations,
        vector<double> *allocated_fractions, vector<double> *allocated_treatment_fractions)
        : Reservoir(name,
                    id,
                    catchments,
                    capacity,
                    max_treatment_capacity,
                    evaporation_series,
                    storage_area_curve,
                    allocated_treatment_fractions,
                    allocated_fractions,
                    wss_with_allocations,
                    ALLOCATED_RESERVOIR),
          has_water_quality_pool(wq_pool_id != NON_INITIALIZED) {
}

AllocatedReservoir::AllocatedReservoir(const char *name, const int id, const vector<Catchment *> &catchments,
                                       const double capacity, const double max_treatment_capacity,
                                       EvaporationSeries &evaporation_series, DataSeries *storage_area_curve,
                                       const vector<double> &construction_time_range, double permitting_period,
                                       Bond &bond, vector<int> *wss_with_allocations,
                                       vector<double> *allocated_fractions,
                                       vector<double> *allocated_treatment_fractions)
        : Reservoir(name, id, catchments, capacity, max_treatment_capacity, evaporation_series, storage_area_curve,
                    allocated_treatment_fractions, allocated_fractions, wss_with_allocations,
                    construction_time_range, permitting_period, bond, ALLOCATED_RESERVOIR),
          has_water_quality_pool(wq_pool_id != NON_INITIALIZED) {
}

AllocatedReservoir::AllocatedReservoir(
        const char *name, const int id, const vector<Catchment *> &catchments,
        const double capacity, const double max_treatment_capacity,
        EvaporationSeries &evaporation_series, double storage_area,
        vector<int> *wss_with_allocations,
        vector<double> *allocated_fractions, vector<double>
        *allocated_treatment_fractions)
        : Reservoir(name,
                    id,
                    catchments,
                    capacity,
                    max_treatment_capacity,
                    evaporation_series,
                    storage_area,
                    allocated_treatment_fractions,
                    allocated_fractions,
                    wss_with_allocations,
                    ALLOCATED_RESERVOIR),
          has_water_quality_pool(wq_pool_id != NON_INITIALIZED) {
}

AllocatedReservoir::AllocatedReservoir(const char *name, const int id, const vector<Catchment *> &catchments,
                                       const double capacity, const double max_treatment_capacity,
                                       EvaporationSeries &evaporation_series, double storage_area,
                                       const vector<double> &construction_time_range, double permitting_period,
                                       Bond &bond, vector<int> *wss_with_allocations,
                                       vector<double> *allocated_fractions,
                                       vector<double> *allocated_treatment_fractions)
        : Reservoir(name, id, catchments, capacity, max_treatment_capacity, evaporation_series, storage_area,
                    allocated_treatment_fractions, allocated_fractions, wss_with_allocations,
                    construction_time_range, permitting_period, bond, ALLOCATED_RESERVOIR),
          has_water_quality_pool(wq_pool_id != NON_INITIALIZED) {
}

AllocatedReservoir::AllocatedReservoir(
        const AllocatedReservoir &allocated_reservoir)
        : Reservoir(allocated_reservoir), has_water_quality_pool(allocated_reservoir.has_water_quality_pool) {}

/**
 * Copy assignment operator
 * @param allocated_reservoir
 * @return
 */
AllocatedReservoir &AllocatedReservoir::operator=(
        const AllocatedReservoir &allocated_reservoir) {
    return *this;
};

AllocatedReservoir::~AllocatedReservoir() = default;


void AllocatedReservoir::applyContinuity(int week, double upstream_source_inflow,
                                         double wastewater_inflow, vector<double> &demand_outflow) {

    double total_upstream_inflow;
    continuity_error = 0;

    total_upstream_inflow = upstream_source_inflow +
            wastewater_inflow;

    this->upstream_source_inflow = upstream_source_inflow;
    this->wastewater_inflow = wastewater_inflow;

    double available_volume_old = available_volume;
    
    total_demand = 0.0;
    for (double i : demand_outflow) {
        total_demand += i;
    }

    double direct_demand = total_demand;


    // Constrain outflow to what is available on water quality pool.
    min_environmental_outflow = (has_water_quality_pool ?
                                 min(min_environmental_outflow, available_allocated_volumes.back()) :
                                 min_environmental_outflow);
    double outflow_new = min_environmental_outflow;
    total_outflow = outflow_new;

    // Calculate total runoff inflow reaching reservoir from its watershed.
    upstream_catchment_inflow = 0;
    for (Catchment &c : catchments)
        upstream_catchment_inflow += c.getStreamflow(week);

    // Calculates water lost through evaporation.
    evaporated_volume =
            (fixed_area ? area * evaporation_series.getEvaporation(week) :
             storage_area_curve->get_dependent_variable(available_volume) *
             evaporation_series.getEvaporation(week));

    // Calculate new stored volume and outflow based on continuity.
    double available_volume_new = available_volume
                                  + total_upstream_inflow
                                  + upstream_catchment_inflow
                                  - total_demand
                                  - min_environmental_outflow
                                  - evaporated_volume;

    // Check if spillage is needed and, if so, correct stored volume and
    // calculate spillage and set all allocations to full. Otherwise,
    // distributed inflows and outflows among respective allocations.
    if (available_volume_new > capacity) {
        for (int u : *wss_with_allocations)
            available_allocated_volumes[u] = this->capacity *
                                             allocated_fractions[u];
        total_outflow = outflow_new + available_volume_new - capacity;
        available_volume = capacity;
    } else {
            available_volume = available_volume_new;
            // Water exceeding allocated capacities.
            double excess_allocated_water = 0.f;
            double fraction_needing_water = 0.f;

            // Volume of water that entered the reservoir and stayed until being
            // used or released.
            double net_inflow = upstream_catchment_inflow +
                                total_upstream_inflow - evaporated_volume;

            bool overallocation;
            if (has_water_quality_pool) {
                overallocation = mass_balance_with_wq_pool(net_inflow,
                                                           demand_outflow);
            } else {
                overallocation = mass_balance_without_wq_pool(net_inflow,
                                                              demand_outflow);
            }

            // Split among utilities any allocated volume exceeding a giver
            // utility's maximum allocated capacity.
            if (overallocation) {
                // Calculate combined excess allocation and combined allocation
                // fraction.
                for (int u : *wss_with_allocations) {
                    // Calculation of amount exceeding all individual allocations
                    if (available_allocated_volumes[u] >=
                        allocated_capacities[u]) {
                        excess_allocated_water += available_allocated_volumes[u]
                                                  - allocated_capacities[u];
                        available_allocated_volumes[u] = allocated_capacities[u];
                    } else
                        fraction_needing_water += allocated_fractions[u];
                }

                // Redistribute combined excess among utilities based on their
                // allocation fractions. If one is exceeded, roll "second order"
                // excess down to the next utility.
                double rellocation_excess = 0;
                while (excess_allocated_water > 0 &&
                       fraction_needing_water > 0) {
                    for (int u : *wss_with_allocations) {
                        // Redistribute excess based on allocations fractions.
                        if (available_allocated_volumes[u] <
                            allocated_capacities[u]) {
                            available_allocated_volumes[u] +=
                                    excess_allocated_water *
                                    (allocated_fractions[u]
                                     / fraction_needing_water);

                            // Check if redistribution of excesses didn't make an
                            // allocation exceed its capacity.
                            if (available_allocated_volumes[u] >
                                allocated_capacities[u]) {
                                rellocation_excess += (
                                        available_allocated_volumes[u]
                                        - allocated_capacities[u]);
                                available_allocated_volumes[u] = allocated_capacities[u];
                            }
                        }
                    }

                    // If there was too much water added to an allocation,
                    // redistribute it.
                    excess_allocated_water = rellocation_excess;
                    rellocation_excess = 0;
                    fraction_needing_water = 0;
                    for (int u : *wss_with_allocations) {
                        if (available_allocated_volumes[u] <
                            allocated_capacities[u])
                            fraction_needing_water += allocated_fractions[u];
                    }
                }

                // If there's still an excess but all allocations are at capacity,
                // release the rest as environmental flows.
                for (int u : *wss_with_allocations) {
                    if (available_allocated_volumes[u] >
                        allocated_capacities[u]) {
                        total_outflow += available_allocated_volumes[u] -
                                         allocated_capacities[u];
                        available_allocated_volumes[u] = allocated_capacities[u];
                    }
                }
            }
        }

    total_demand += policy_added_demand;

    // Sanity checking from now on.
    double sum_allocations = accumulate(available_allocated_volumes.begin(),
                                        available_allocated_volumes.end(),
                                        0.f);

    double cont_error = abs(available_volume_old - direct_demand + total_upstream_inflow +
                            upstream_catchment_inflow - evaporated_volume -
                            total_outflow - available_volume) - abs(continuity_error);

    if (continuity_error > 0) {
        printf("Warning: continuity error of %f in allocated reservoir %d.\n", continuity_error, id);
    }

    if ((int) abs(sum_allocations - available_volume) > 1) {
        string error = "Sum of allocated volumes in a reservoir must \n"
                        "total current storage minus unallocated \n"
                        "volume.Please report this error to \n"
                        "bct52@cornell.edu.\n\n"
                        "week: " + to_string(week) + "\nsum_allocations: " + to_string(sum_allocations) + "\n"
                        "available_volume_old: " + to_string(available_volume_old) + "\navailable_volume " + to_string(available_volume) + "\n"
                        "total_upstream_inflow: " + to_string(total_upstream_inflow) + "\n"
                        "upstream_catchment_inflow: " + to_string(upstream_catchment_inflow) + "\nevaporation: " + to_string(evaporated_volume) + "\n"
                        "total_demand: " + to_string(total_demand) + "\npolicy_added_demand: " + to_string(policy_added_demand) + "\n"
                        "total_outflow: " + to_string(total_outflow) + "\ncontinuity error: " + to_string(cont_error);

	throw runtime_error(error);
//        throw_with_nested(runtime_error(error));
    }

    if (abs(cont_error) > 1.f || available_volume < -1.f || sum_allocations < -1.f) {
        string error = "Continuity error in " + string(name) + "\n\n"
                        "week: " + to_string(week) + "\nsum_allocations: " + to_string(sum_allocations) + "\n"
                        "available_volume_old: " + to_string(available_volume_old) + "\navailable_volume " + to_string(available_volume) + "\n"
                        "total_upstream_inflow: " + to_string(total_upstream_inflow) + "\n"
                        "upstream_catchment_inflow: " + to_string(upstream_catchment_inflow) + "\nevaporation: " + to_string(evaporated_volume) + "\n"
                        "total_demand: " + to_string(total_demand) + "\npolicy_added_demand: " + to_string(policy_added_demand) + "\n"
                        "total_outflow: " + to_string(total_outflow) + "\ncontinuity error: " + to_string(cont_error);

	throw runtime_error(error);
//        throw_with_nested(runtime_error(error));
    } else if (available_volume < 0) {
	available_volume = 0;
    }

    policy_added_demand = 0;
}

void AllocatedReservoir::addCapacity(double capacity) {
    WaterSource::addCapacity(capacity);

    for (int i : *wss_with_allocations)
        allocated_capacities[i] += capacity * allocated_fractions[i];
}

/**
 * Addes treatment capacity to a source. The specification of both the total
 * treatment capacity of the new plant and the fraction of the treatment
 * capacity allocated to a given utility allow for joint treatment plants. To
 * have one utility only building an exclusive plant, the fraction will be 1.
 * @param added_plant_treatment_capacity
 * @param allocated_fraction_of_total_capacity
 * @param system_id
 */
void AllocatedReservoir::addTreatmentCapacity(const double added_plant_treatment_capacity, int system_id) {
    WaterSource::addTreatmentCapacity(added_plant_treatment_capacity, system_id);

    // Add capacity to respective treatment allocation.
    allocated_treatment_capacities[system_id] +=
            added_plant_treatment_capacity;

    // Update treatment allocation fractions based on new allocated amounts
    // and new total treatment capacity.
    for (int i = 0; i < (int) wss_with_allocations->size(); ++i) {
        allocated_treatment_fractions[i] = allocated_treatment_capacities[i]
                                           / total_treatment_capacity;
    }
}

bool AllocatedReservoir::mass_balance_with_wq_pool(double net_inflow,
                                                     vector<double>
                                                     &demand_outflow) {
    bool overallocation = false;
    int u;
    double negative_utility_allocation = 0;
    for (int i = 0; i < (int) wss_with_allocations->size() - 1; ++i) {
        u = (*wss_with_allocations)[i];
        // Split inflows and evaporation among allocations and
        // subtract demands.
        available_allocated_volumes[u] +=
                net_inflow * allocated_fractions[u] -
                demand_outflow[u];

        // Flag the occurrence of an allocation exceeding its capacity
        if (!overallocation) {
            overallocation = available_allocated_volumes[u] >
                             allocated_capacities[u];
        }

        /**
         * If allocated volume gets negative for any utility, charge that consumption (basically evaporation)
         * to the water quality pool. Improvements can be made to this, but it may make code significantly slower.
         */
        if (available_allocated_volumes[u] < 0) {
            negative_utility_allocation += available_allocated_volumes[u];
            available_allocated_volumes[u] = 0;
        }
    }

    // the water quality pool has no demand but provides the
    // minimum environmental flows.
    u = wss_with_allocations->back();
    available_allocated_volumes[u] +=
            net_inflow * allocated_fractions[u] -
            min_environmental_outflow + negative_utility_allocation;

    // Flag the occurrence of an allocation exceeding its capacity
    if (!overallocation) {
        overallocation = available_allocated_volumes[u] >
                         allocated_capacities[u];
    }

    // Get water from water quality pool for supply. Check continuity for errors.
    if (available_allocated_volumes[u] < 0) {
        if (total_outflow + available_allocated_volumes[u] < 0) {
            continuity_error = total_outflow + available_allocated_volumes[u];
            total_outflow = 0;
        } else {
            total_outflow += available_allocated_volumes[u];
        }
        available_volume -= available_allocated_volumes[u];
        available_allocated_volumes[u] = 0;
    }

    return overallocation;
}

bool AllocatedReservoir::mass_balance_without_wq_pool(double net_inflow,
                                                   vector<double>
                                                   &demand_outflow) {
    bool overallocation = false;
    net_inflow -= min_environmental_outflow;
    for (int u : *wss_with_allocations) {
        // Split inflows, min environmental outflows and evaporation among
        // allocations and subtract demands.
        available_allocated_volumes[u] +=
                net_inflow * allocated_fractions[u] -
                demand_outflow[u];

        // Flag the occurrence of an allocation exceeding its capacity
        if (!overallocation)
            overallocation = available_allocated_volumes[u] >
                             allocated_capacities[u];
    }

    return overallocation;
}

void AllocatedReservoir::setOnline() {
    Reservoir::setOnline();

    // start empty and gradually fill as inflows start coming in.
    available_volume = 0;
    //set all allocated volumes to zero
    for (int u : *wss_with_allocations) {
        available_allocated_volumes[u] = 0;
    }
}

double AllocatedReservoir::getAvailableAllocatedVolume(int system_id) {
    // Bounds check: if this WSS doesn't have allocations from this reservoir, return 0
    if (system_id < 0 || system_id >= (int)available_allocated_volumes.size()) {
        return 0.0;
    }
    return available_allocated_volumes[system_id];
}

void AllocatedReservoir::removeWater(int allocation_id, double volume) {
    // Bounds check: if this WSS doesn't have allocations from this reservoir, ignore
    if (allocation_id < 0 || allocation_id >= (int)available_allocated_volumes.size()) {
        return;
    }
    available_allocated_volumes[allocation_id] -= volume;
    available_volume -= volume;
    total_demand += volume;
    policy_added_demand += volume;
}

double AllocatedReservoir::getAllocatedCapacity(int system_id) {
    return allocated_capacities[system_id];
}

void AllocatedReservoir::setFull() {
    WaterSource::setFull();
    for (int u : *wss_with_allocations)
        available_allocated_volumes[u] = allocated_capacities[u];
}

double AllocatedReservoir::getAllocatedFraction(int system_id) {
    // Bounds check: if this WSS doesn't have allocations from this reservoir, return 0
    if (system_id < 0 || system_id >= (int)allocated_fractions.size()) {
        return 0.0;
    }
    return allocated_fractions[system_id];
}

double AllocatedReservoir::getAllocatedTreatmentCapacity(int system_id) const {
    if (system_id == WATER_QUALITY_ALLOCATION)
        throw invalid_argument("Water quality pool does not have allocated treatment "
                                     "capacity.");
    
    // Bounds check: if this WSS doesn't have allocations from this reservoir, return 0
    if (system_id < 0 || system_id >= (int)allocated_treatment_capacities.size()) {
        return 0.0;
    }
    
    return allocated_treatment_capacities[system_id];
}

double AllocatedReservoir::getSupplyAllocatedFraction(int system_id) {
    if (system_id == WATER_QUALITY_ALLOCATION)
        throw invalid_argument("Water quality pool allocation fraction cannot "
                                         "be used for supply.");
    
    // Bounds check: if this WSS doesn't have allocations from this reservoir, return 0
    if (system_id < 0 || system_id >= (int)supply_allocated_fractions.size()) {
        return 0.0;
    }
    
    return supply_allocated_fractions[system_id];
}
