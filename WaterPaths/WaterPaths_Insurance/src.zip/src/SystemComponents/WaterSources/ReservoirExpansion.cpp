//
// Created by bernardoct on 5/12/17.
//

#include <stdexcept>
#include "ReservoirExpansion.h"
//

#include "ReservoirExpansion.h"

ReservoirExpansion::ReservoirExpansion(const char *name, const int id, const unsigned int parent_reservoir_ID,
                                       const double capacity, const vector<double> &construction_time_range,
                                       double permitting_period, Bond &bond)
        : WaterSource(name, id, vector<Catchment *>(), capacity, NON_INITIALIZED, vector<int>(), RESERVOIR_EXPANSION,
                      construction_time_range, permitting_period, bond),
          parent_reservoir_ID(parent_reservoir_ID) {}

/**
 * Copy constructor.
 * @param reservoir
 */
ReservoirExpansion::ReservoirExpansion(const ReservoirExpansion &reservoir_expansion) :
        WaterSource(reservoir_expansion),
        parent_reservoir_ID(reservoir_expansion.parent_reservoir_ID) {}

/**
 * Copy assignment operator
 * @param reservoir
 * @return
 */
ReservoirExpansion &ReservoirExpansion::operator=(const ReservoirExpansion &reservoir_expansion) {
    WaterSource::operator=(reservoir_expansion);
    return *this;
}

void ReservoirExpansion::applyContinuity(int week, double upstream_source_inflow,
                                         double wastewater_discharge,
                                         vector<double> &demand_outflow) {
    throw std::logic_error("Reservoir expansion only add storage volume to the "
                                "reservoir they're assigned to.  Continuity "
                                "cannot be called on it, but only on the "
                                "reservoir it's  assigned to expand.");
}

/**
 * Reservoir expansions don't run continuity independently - they just add storage
 * capacity to their parent reservoir. Override to always bypass.
 */
void ReservoirExpansion::continuityWaterSource(int week, double upstream_source_inflow,
                                               double wastewater_inflow,
                                               vector<double> &demand_outflow) {
    // Always bypass - reservoir expansions don't have their own continuity
    bypass(week, upstream_source_inflow + wastewater_inflow);
}
