//
// Created by bernardo on 4/12/18.
//

#ifndef TRIANGLEMODEL_BONDFINANCING_H
#define TRIANGLEMODEL_BONDFINANCING_H

#include <vector>
#include "../../../Utils/Constants.h"

using namespace std;
using namespace Constants;

class Bond {
private:
    bool issued = false;
protected:
    int week_issued;
    double cost_of_capital;
    double coupon_rate;
    int n_payments;
    int begin_repayment_after_n_years = NON_INITIALIZED;
    
    // Store original values to restore between realizations
    const double original_cost_of_capital;
    const double original_coupon_rate;
    const int original_n_payments;
public:
    const int type;
    const vector<int> pay_on_weeks;
    const int id;

    Bond(const int id, const double cost_of_capital, const int n_payments, vector<int> pay_on_weeks,
                  const int type, bool begin_repayment_at_issuance = false);

    Bond(const int id, const double cost_of_capital, const int n_payments, vector<int> pay_on_weeks,
         const double coupon_rate, const int type, bool begin_repayment_at_issuance = false);

    Bond();

    virtual ~Bond();

    Bond(const Bond&) = default;

    virtual double getDebtService(int week) = 0;

    virtual double getNetPresentValueAtIssuance(double discount_rate, int week) const = 0;

    virtual void
    issueBond(int week, int construction_time, double bond_term_multiplier, double bond_interest_rate_multiplier);

    virtual void setRealizationWaterSource(unsigned long r, vector<double> &rdm_factors);

    bool isIssued() const;

    void setIssued();
    
    // Reset bond state for a new realization (clear payment history from ROF generation)
    virtual void resetForRealization() { 
        issued = false; 
        week_issued = NON_INITIALIZED;
        // Restore original values that get modified by RDM multipliers
        cost_of_capital = original_cost_of_capital;
        coupon_rate = original_coupon_rate;
        n_payments = original_n_payments;
    }

};


#endif //TRIANGLEMODEL_BONDFINANCING_H
