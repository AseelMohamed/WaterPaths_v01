//
// Created by bernardo on 4/12/18.
//

#include <stdexcept>
#include "Bond.h"

Bond::Bond(const int id, const double cost_of_capital, const int n_payments,
           vector<int> pay_on_weeks, const int type,
           bool begin_repayment_at_issuance) :
        id(id), cost_of_capital(cost_of_capital), n_payments(n_payments),
        pay_on_weeks(pay_on_weeks), type(type),
        original_cost_of_capital(cost_of_capital), 
        original_coupon_rate(0.0),  // Will be set in child constructor if needed
        original_n_payments(n_payments) {

    /// If bond is to start being paid for at issuance, set repayment delay
    /// to 0. Otherwise it will be set at issuance.
    if (begin_repayment_at_issuance) {
        begin_repayment_after_n_years = 0;
    }

    if (std::isnan(cost_of_capital) || cost_of_capital < 0) {
        string error = "Invalid construction cost of capital for bond "
                       + to_string(id);
        throw std::invalid_argument(error.c_str());
    }
}

Bond::Bond(const int id, const double cost_of_capital, const int n_payments,
           vector<int> pay_on_weeks, const double coupon_rate, const int type,
           bool begin_repayment_at_issuance) :
        id(id), cost_of_capital(cost_of_capital), n_payments(n_payments),
        pay_on_weeks(pay_on_weeks),
        coupon_rate(coupon_rate), type(type),
        original_cost_of_capital(cost_of_capital),
        original_coupon_rate(coupon_rate),
        original_n_payments(n_payments) {

    /// If bond is to start being paid for at issuance, set repayment delay
    /// to 0. Otherwise it will be set at issuance.
    if (begin_repayment_at_issuance) {
        begin_repayment_after_n_years = 0;
    }

    if (std::isnan(cost_of_capital) || cost_of_capital < 0) {
        string error = "Invalid construction cost of capital for bond "
                       + to_string(id);
        throw std::invalid_argument(error.c_str());
    }
}

Bond::Bond() : id(NON_INITIALIZED), n_payments(NON_INITIALIZED),
               cost_of_capital(NON_INITIALIZED), type(NON_INITIALIZED),
               original_cost_of_capital(NON_INITIALIZED),
               original_coupon_rate(0.0),
               original_n_payments(NON_INITIALIZED) {}

Bond::~Bond() = default;

/**
 * Only cost of capital RDM multiplier is applied here because in a joint
 * project, it is assumed any cost overruns would be split among the
 * utilities. Interest and bond term, on the other hand, are utility
 * dependent are set at issuance, in function issueBond.
 * @param r
 * @param rdm_factors
 */
void Bond::setRealizationWaterSource(unsigned long r,
                                     vector<double> &rdm_factors) {
    cost_of_capital *= rdm_factors[0];
}

void Bond::issueBond(int week, int construction_time,
                     double bond_term_multiplier,
                     double bond_interest_rate_multiplier) {

    /// Set date to begin repayment
    if (begin_repayment_after_n_years == NON_INITIALIZED) {
        begin_repayment_after_n_years =
                (int) (construction_time / WEEKS_IN_YEAR) + 1;
    }

    week_issued = week;
    n_payments *= bond_term_multiplier;
    coupon_rate *= bond_interest_rate_multiplier;
    setIssued();
}

bool Bond::isIssued() const {
    return issued;
}

void Bond::setIssued() {
    Bond::issued = true;
}
